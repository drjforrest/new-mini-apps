"use client";

import { FlagQuiz } from "./components/FlagQuiz";

export default function FlagQuizPage() {
  return (
    <div className="container mx-auto py-8">
      <FlagQuiz />
    </div>
  );
}
