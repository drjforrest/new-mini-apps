import { Button, SimpleDialog } from "@components/index";
import { Flag, Target, Award } from "lucide-react";

interface WelcomePopupProps {
  isOpen: boolean;
  onClose: () => void;
  onStart: () => void;
}

export function WelcomePopup({ isOpen, onClose, onStart }: WelcomePopupProps) {
  return (
    <SimpleDialog
      isOpen={isOpen}
      onClose={onClose}
      title="Welcome to Flag Quiz!"
      description="Test your knowledge of African flags in this interactive quiz."
      footer={
        <>
          <Button variant="outline" onClick={onClose}>
            Maybe Later
          </Button>
          <Button
            onClick={() => {
              onClose();
              onStart();
            }}
          >
            Start Quiz
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        <div className="flex items-start gap-3">
          <Flag className="w-4 h-4 text-primary mt-1" />
          <div>
            <h3 className="font-medium text-foreground mb-1">How to Play</h3>
            <p className="text-muted">
              You&apos;lll be shown a flag and four country options. Select the
              country you think the flag belongs to.
            </p>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <Target className="w-4 h-4 text-primary mt-1" />
          <div>
            <h3 className="font-medium text-foreground mb-1">Scoring</h3>
            <p className="text-muted">
              Each correct answer earns you 10 points. Try to maintain a streak
              for bonus points!
            </p>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <Award className="w-4 h-4 text-primary mt-1" />
          <div>
            <h3 className="font-medium text-foreground mb-1">Game Modes</h3>
            <p className="text-muted">
              Choose between Practice, Challenge, or Regional mode to test your
              knowledge in different ways.
            </p>
          </div>
        </div>
      </div>
    </SimpleDialog>
  );
}
