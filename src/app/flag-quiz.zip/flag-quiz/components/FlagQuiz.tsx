"use client";

import { useState, useEffect, useCallback } from "react";
import { m } from "framer-motion";
import confetti from "canvas-confetti";
import { Card } from "@components/index";
import { AFRICAN_COUNTRIES, type Country } from "../../types/country";
import { StartScreen, GameComplete, GameScreen } from "./index";
import type { QuizState } from "../types/game";
import { WelcomePopup } from "./WelcomePopup";

const pageVariants = {
  initial: {
    opacity: 0,
    x: -20,
  },
  animate: {
    opacity: 1,
    x: 0,
    transition: {
      duration: 0.5,
      ease: "easeOut",
    },
  },
  exit: {
    opacity: 0,
    x: 20,
    transition: {
      duration: 0.3,
      ease: "easeIn",
    },
  },
};

interface QuizGameProps {
  onAnswer: (answer: Country | null) => void;
}

export function QuizGame() {
  const [isClient, setIsClient] = useState(false);
  const [quizState, setQuizState] = useState<QuizState>({
    score: 0,
    currentStreak: 0,
    currentQuestion: null,
    questionIndex: 0,
    gameMode: "practice",
    isGameOver: false,
    showFeedback: false,
    lastAnswer: null,
  });
  const [showWelcome, setShowWelcome] = useState(true);

  const getRandomCountry = useCallback((): Country => {
    const index = Math.floor(Math.random() * AFRICAN_COUNTRIES.length);
    return AFRICAN_COUNTRIES[index];
  }, []);

  const getRandomCountries = useCallback(
    (count: number, exclude: Country): Country[] => {
      const others = AFRICAN_COUNTRIES.filter(
        (c: Country) => c.name !== exclude.name,
      );
      const shuffled = [...others].sort(() => Math.random() - 0.5);
      return shuffled.slice(0, count);
    },
    [],
  );

  const generateQuestion = useCallback(() => {
    const correctCountry = getRandomCountry();
    setQuizState((prev) => ({
      ...prev,
      currentQuestion: correctCountry,
      questionIndex: prev.questionIndex + 1,
      showFeedback: false,
      lastAnswer: null,
    }));
  }, [getRandomCountry]);

  const handleAnswer = useCallback(
    (selectedCountry: Country | null) => {
      if (!selectedCountry) {
        return;
      }

      const isCorrect =
        selectedCountry.name === quizState.currentQuestion?.name;
      const pointsEarned = isCorrect ? 10 : 0;

      if (isCorrect) {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
          colors: ["#2FB8AC", "#2F7BB8", "#B82F3D"],
          zIndex: 1000,
        });
      }

      setQuizState((prevState) => {
        const newState = {
          ...prevState,
          score: prevState.score + pointsEarned,
          currentStreak: isCorrect ? prevState.currentStreak + 1 : 0,
          showFeedback: true,
          lastAnswer: { country: selectedCountry, isCorrect },
        };

        if (prevState.questionIndex >= 9) {
          return {
            ...newState,
            isGameOver: true,
            currentQuestion: null,
          };
        }

        return newState;
      });

      if (!isCorrect) {
        setTimeout(() => {
          generateQuestion();
        }, 3000);
      } else {
        setTimeout(() => {
          generateQuestion();
        }, 2000);
      }
    },
    [quizState.currentQuestion, generateQuestion],
  );

  const handleRestart = useCallback(() => {
    setQuizState({
      score: 0,
      currentStreak: 0,
      currentQuestion: null,
      questionIndex: 0,
      gameMode: "practice",
      isGameOver: false,
      showFeedback: false,
      lastAnswer: null,
    });
    generateQuestion();
  }, [generateQuestion]);

  const handleModeChange = useCallback(
    (mode: "practice" | "challenge" | "regional") => {
      setQuizState((prev) => ({ ...prev, gameMode: mode }));
    },
    [],
  );

  useEffect(() => {
    setIsClient(true);
  }, []);

  useEffect(() => {
    if (!quizState.currentQuestion && !quizState.isGameOver) {
      generateQuestion();
    }
  }, [quizState.currentQuestion, quizState.isGameOver, generateQuestion]);

  if (!isClient) {
    return null;
  }

  const currentQuizContent = () => {
    if (!quizState.currentQuestion && !quizState.isGameOver) {
      return (
        <m.div
          key="start"
          variants={pageVariants}
          initial="initial"
          animate="animate"
          exit="exit"
        >
          <StartScreen onStart={() => generateQuestion()} />
        </m.div>
      );
    }

    if (quizState.isGameOver) {
      return (
        <m.div
          key="complete"
          variants={pageVariants}
          initial="initial"
          animate="animate"
          exit="exit"
        >
          <GameComplete score={quizState.score} onRestart={handleRestart} />
        </m.div>
      );
    }

    if (quizState.currentQuestion) {
      const options = [
        quizState.currentQuestion,
        ...getRandomCountries(3, quizState.currentQuestion),
      ].sort(() => Math.random() - 0.5);

      return (
        <m.div
          key={`question-${quizState.questionIndex}`}
          variants={pageVariants}
          initial="initial"
          animate="animate"
          exit="exit"
        >
          <GameScreen
            currentFlag={quizState.currentQuestion}
            options={options}
            currentQuestion={quizState.questionIndex}
            score={quizState.score}
            onAnswer={handleAnswer}
            showFeedback={quizState.showFeedback}
            lastAnswer={quizState.lastAnswer}
          />
        </m.div>
      );
    }
  };

  return (
    <div className="min-h-screen bg-background px-4 py-8">
      <WelcomePopup
        isOpen={showWelcome}
        onClose={() => setShowWelcome(false)}
        onStart={() => {
          setShowWelcome(false);
          generateQuestion();
        }}
      />
      <Card className="max-w-4xl mx-auto p-6 bg-surface border-border">
        <div className="space-y-8">
          {/* Game Header */}
          <div className="flex justify-between items-center">
            <div className="space-y-1">
              <m.p
                className="text-lg font-semibold text-foreground"
                animate={{ scale: [1, 1.05, 1] }}
                transition={{ duration: 0.3 }}
                key={quizState.score}
              >
                Score: {quizState.score}
              </m.p>
              <div className="flex items-center gap-2">
                <p className="text-sm text-muted">Current Streak:</p>
                <m.span
                  className="text-sm font-medium text-accent"
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 0.3 }}
                  key={quizState.currentStreak}
                >
                  {quizState.currentStreak}
                </m.span>
              </div>
            </div>
            <m.select
              value={quizState.gameMode}
              onChange={(e) =>
                handleModeChange(
                  e.target.value as "practice" | "challenge" | "regional",
                )
              }
              className="px-3 py-2 rounded-md border border-border bg-surface text-foreground"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <option value="practice">Practice Mode</option>
              <option value="challenge">Challenge Mode</option>
              <option value="regional">Regional Mode</option>
            </m.select>
          </div>

          {/* Game Content */}
          {currentQuizContent()}
        </div>
      </Card>
    </div>
  );
}
