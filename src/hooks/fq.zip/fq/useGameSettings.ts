import { useState, useEffect } from 'react';
import { Difficulty } from '../types/game';

interface GameSettings {
  difficulty: Difficulty;
  sound: boolean;
  showHints: boolean;
}

const DEFAULT_SETTINGS: GameSettings = {
  difficulty: Difficulty.Easy,
  sound: true,
  showHints: true,
};

export function useGameSettings() {
  const [settings, setSettings] = useState<GameSettings>(DEFAULT_SETTINGS);

  useEffect(() => {
    const stored = localStorage.getItem('flag-quiz-settings');
    if (stored) {
      setSettings(JSON.parse(stored));
    }
  }, []);

  const updateSettings = (newSettings: Partial<GameSettings>) => {
    const updated = { ...settings, ...newSettings };
    setSettings(updated);
    localStorage.setItem('flag-quiz-settings', JSON.stringify(updated));
  };

  return { settings, updateSettings };
} 